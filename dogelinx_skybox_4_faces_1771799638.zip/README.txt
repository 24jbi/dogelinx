4 images (sides only) cut from your cross image.

Files:
  nx.png / left.png   = Left  (-X)
  pz.png / front.png  = Front (+Z)
  px.png / right.png  = Right (+X)
  nz.png / back.png   = Back  (-Z)  <-- not present in your source; made by mirroring front as a placeholder.
